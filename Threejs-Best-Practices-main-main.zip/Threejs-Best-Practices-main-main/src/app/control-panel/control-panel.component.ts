import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { BoxGeometry, BufferGeometry, SphereGeometry } from 'three';
import { InstantiateMethods } from '../world/world.component';

@Component({
  selector: 'app-control-panel',
  templateUrl: './control-panel.component.html',
  styleUrls: ['./control-panel.component.less']
})
export class ControlPanelComponent implements OnInit {
  @Input()
  drawCalls: number;
  @Input()
  triangles: number;
  @Input()
  antiAliasing: boolean;
  @Output()
  antiAliasingChange = new EventEmitter<boolean>();
  @Input()
  objectsAmount: number;
  @Output()
  objectsAmountChange = new EventEmitter<number>();
  @Input()
  objectsMaxAmount: number;
  @Input()
  materialTransparency: boolean;
  @Output()
  materialTransparencyChange = new EventEmitter<boolean>();
  @Input()
  instantiateMethod: InstantiateMethods;
  @Output()
  instantiateMethodChange = new EventEmitter<InstantiateMethods>();
  instantiateMethods = InstantiateMethods;
  @Input()
  shadowsOn: boolean;
  @Output()
  shadowsOnChange = new EventEmitter<boolean>();
  @Input()
  objectGeometry: BufferGeometry;
  @Output()
  objectGeometryChange = new EventEmitter<BufferGeometry>();
  @Input()
  useLod: boolean;
  @Output()
  useLodChange = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit(): void { }

  setObjectsAmount(event: any) {
    this.objectsAmount = event.target.value;
    this.objectsAmountChange.emit(this.objectsAmount);
  }

  setAntiAliasing(values: any) {
    this.antiAliasing = values.currentTarget.checked;
    this.antiAliasingChange.emit(this.antiAliasing);
  }

  setInstantiateMethod(values: any) {
    this.instantiateMethod = values.target.value;
    this.instantiateMethodChange.emit(this.instantiateMethod);
  }

  getKeys(obj: any) {
    return Object.keys(obj).filter(key => isNaN(Number(obj[key])));
  }

  setShadowsOn(values: any) {
    this.shadowsOn = values.currentTarget.checked;
    this.shadowsOnChange.emit(this.shadowsOn);
  }

  setLodOn(values: any) {
    this.useLod = values.currentTarget.checked;
    this.useLodChange.emit(this.useLod);
  }

  setMaterialTransparency(values: any) {
    this.materialTransparency = values.currentTarget.checked;
    this.materialTransparencyChange.emit(this.materialTransparency);
  }

  setObjectGeometry(values: any) {
    switch(values.target.value) {
      case "cube":
        this.objectGeometry = new BoxGeometry(20, 20, 20).toNonIndexed();
        break;
      case "sphere":
        this.objectGeometry = new SphereGeometry(20).toNonIndexed();
        this.objectGeometry.name = "sphere";
        break;
      default:
        this.objectGeometry = new BoxGeometry(20, 20, 20).toNonIndexed();
    }

    this.objectGeometryChange.emit(this.objectGeometry);
  }
}
