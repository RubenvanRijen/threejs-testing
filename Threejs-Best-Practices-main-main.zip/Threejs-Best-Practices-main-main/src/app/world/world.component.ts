import {Component, KeyValueDiffer, KeyValueDiffers, OnInit} from '@angular/core';
import Stats from 'three/examples/jsm/libs/stats.module.js';
import {TransformControls} from 'three/examples/jsm/controls/TransformControls';
import {OrbitControls} from 'three/examples/jsm/controls/OrbitControls';
import {
  AmbientLight,
  BoxGeometry,
  BufferGeometry,
  Color,
  Euler,
  Float32BufferAttribute,
  GridHelper,
  Group,
  InstancedMesh,
  LOD,
  Material, MathUtils,
  Matrix4,
  Mesh,
  MeshPhongMaterial,
  Object3D,
  PCFShadowMap,
  PerspectiveCamera,
  Quaternion,
  Scene,
  SphereGeometry,
  SpotLight,
  Vector3,
  WebGLRenderer
} from 'three';
import * as $ from 'jquery';


export enum InstantiateMethods {
  Default,
  Group,
  InstanceMesh
}

@Component({
  selector: 'app-world',
  templateUrl: './world.component.html',
  styleUrls: ['./world.component.less']
})

export class WorldComponent implements OnInit {
  private container: HTMLElement;
  private camera: PerspectiveCamera;
  private scene: Scene;
  private renderer: WebGLRenderer;
  private transformControl: TransformControls;
  private controls: OrbitControls;
  private stats: Stats;
  private color = new Color();
  private objects: Object3D[] = [];
  private differ: KeyValueDiffer<string, any>;
  public canvas: HTMLCanvasElement;
  private theta: number;
  private radius = 100;
  private canSpin: boolean;
  private measurements = {
    fps: [],
    drawCalls: [],
  };
  private lastCalledTime;
  private fps;
  // Control panel
  public antiAliasing: boolean = false;
  public drawCalls: number = 0;
  public triangles: number = 0;
  public objectsAmount: number = 1800;
  public objectsMaxAmount: number = 21000;
  public materialTransparency: boolean = false;
  public instantiateMethod: InstantiateMethods = InstantiateMethods.Default;
  public shadowsOn: boolean = false;
  public objectGeometry: BufferGeometry = new BoxGeometry(20, 20, 20).toNonIndexed();
  public useLod: boolean = false;

  private sphereLodGeometry = [
    [new SphereGeometry(20, 8, 6), 400],
    [new SphereGeometry(20, 6, 5), 800],
    [new SphereGeometry(20, 5, 4), 1200],
    [new SphereGeometry(20, 4, 3), 1600],
    [new SphereGeometry(20, 3, 2), 2000]
  ];

  constructor(private differs: KeyValueDiffers) {
    this.theta = 0;
    this.canSpin = false;
    this.differ = this.differs.find({}).create();
    this.keyStrokes();
  }

  // tslint:disable-next-line:use-lifecycle-interface
  ngDoCheck() {
    const change = this.differ.diff(this);
    if (change) {
      change.forEachChangedItem(item => {
        if (item.key == "antiAliasing" || item.key == "shadowsOn") {
          this.cleanScene();
          this.createScene();
        }
        if (item.key == "objectsAmount" || item.key == "instantiateMethod"
          || item.key == "objectGeometry" || item.key == "materialTransparency" || item.key == "useLod") {
          this.spawnObjects();
        }
      });
    }
  }

  cleanScene(): void {
    cancelAnimationFrame(this.scene.id); // Stop the animation
    this.renderer.domElement.addEventListener('dblclick', null, false); // remove listener to render
    this.scene = null;
    this.camera = null;
    this.controls = null;
    this.empty(this.container);
  }

  empty(elem: HTMLElement): void {
    while (elem.lastChild) {
      if (elem.lastChild.textContent.length > 0) {
        break;
      }
      elem.removeChild(elem.lastChild);
    }
  }

  keyStrokes() {
    const onKeyDown = (event) => {
      switch (event.code) {
        case 'KeyS':
          this.canSpin = this.canSpin !== true;
          console.log(this.measurements);
          break;
      }
    };
    document.addEventListener('keydown', onKeyDown);
  }

  spawnObjects(): void {
    this.objects.forEach((obj) => {
      this.scene.remove(obj);
    });
    this.objects = [];

    const method = this.instantiateMethod.toString();
    switch (method) {
      case InstantiateMethods.Default.toString():
        this.spawnObjectsDefault();
        break;
      case InstantiateMethods.Group.toString():
        this.spawnObjectsGroup();
        break;
      case InstantiateMethods.InstanceMesh.toString():
        this.spawnObjectsInstancedMesh();
        break;
      default:
        this.spawnObjectsDefault();
    }
  }

  spawnObjectsDefault(): void {
    const position = this.objectGeometry.attributes.position;
    const colorsBox = [];

    for (let i = 0, l = position.count; i < l; i++) {
      this.color.setHSL(Math.random() * 0.3 + 0.5, 0.75, Math.random() * 0.25 + 0.75);
      colorsBox.push(this.color.r, this.color.g, this.color.b);
    }

    this.objectGeometry.setAttribute('color', new Float32BufferAttribute(colorsBox, 3));

    const boxMaterial = new MeshPhongMaterial({specular: 0xffffff, flatShading: true, vertexColors: true});
    boxMaterial.color.setHSL(0.60, 0.75, 0.81);
    boxMaterial.transparent = this.materialTransparency;
    boxMaterial.opacity = this.materialTransparency === true ? 0.2 : 1;

    if (this.useLod === true && this.objectGeometry.name === "sphere") {
      for (let j = 0; j < this.objectsAmount; j++) {
        const lod = new LOD();

        for (let i = 0; i < this.sphereLodGeometry.length; i++) {
          const mesh = new Mesh(this.sphereLodGeometry[i][0] as SphereGeometry, boxMaterial);
          mesh.castShadow = this.shadowsOn;
          mesh.receiveShadow = this.shadowsOn;

          mesh.position.x = Math.floor(Math.random() * 20 - 10) * 20;
          mesh.position.y = Math.floor(Math.random() * 20) * 20 + 10;
          mesh.position.z = Math.floor(Math.random() * 20 - 10) * 20;

          mesh.updateMatrix();
          mesh.matrixAutoUpdate = false;
          lod.addLevel(mesh, this.sphereLodGeometry[i][1] as number);
        }

        lod.updateMatrix();
        lod.matrixAutoUpdate = false;
        this.scene.add(lod);
        this.objects.push(lod);
      }
    } else {
      for (let i = 0; i < this.objectsAmount; i++) {
        const box = new Mesh(this.objectGeometry, boxMaterial);
        box.castShadow = this.shadowsOn;
        box.receiveShadow = this.shadowsOn;

        box.position.x = Math.floor(Math.random() * 20 - 10) * 20;
        box.position.y = Math.floor(Math.random() * 20) * 20 + 10;
        box.position.z = Math.floor(Math.random() * 20 - 10) * 20;

        this.scene.add(box);
        this.objects.push(box);
      }
    }
  }

  spawnObjectsGroup(): void {
    let group = new Group();

    const position = this.objectGeometry.attributes.position;
    const colorsBox = [];

    for (let i = 0, l = position.count; i < l; i++) {
      this.color.setHSL(Math.random() * 0.3 + 0.5, 0.75, Math.random() * 0.25 + 0.75);
      colorsBox.push(this.color.r, this.color.g, this.color.b);
    }

    this.objectGeometry.setAttribute('color', new Float32BufferAttribute(colorsBox, 3));

    const boxMaterial = new MeshPhongMaterial({specular: 0xffffff, flatShading: true, vertexColors: true});
    boxMaterial.color.setHSL(0.60, 0.75, 0.81);
    boxMaterial.transparent = this.materialTransparency;
    boxMaterial.opacity = this.materialTransparency === true ? 0.2 : 1;

    if (this.useLod === true && this.objectGeometry.name === "sphere") {
      for (let j = 0; j < this.objectsAmount; j++) {
        const lod = new LOD();

        for (let i = 0; i < this.sphereLodGeometry.length; i++) {
          const mesh = new Mesh(this.sphereLodGeometry[i][0] as SphereGeometry, boxMaterial);
          mesh.castShadow = this.shadowsOn;
          mesh.receiveShadow = this.shadowsOn;

          mesh.position.x = Math.floor(Math.random() * 20 - 10) * 20;
          mesh.position.y = Math.floor(Math.random() * 20) * 20 + 10;
          mesh.position.z = Math.floor(Math.random() * 20 - 10) * 20;

          mesh.updateMatrix();
          mesh.matrixAutoUpdate = false;
          lod.addLevel(mesh, this.sphereLodGeometry[i][1] as number);
        }

        lod.updateMatrix();
        lod.matrixAutoUpdate = false;
        group.add(lod);
      }
      this.scene.add(group);
      this.objects.push(group);
    } else {
      for (let i = 0; i < this.objectsAmount; i++) {
        const box = new Mesh(this.objectGeometry, boxMaterial);
        box.castShadow = this.shadowsOn;
        box.receiveShadow = this.shadowsOn;

        box.position.x = Math.floor(Math.random() * 20 - 10) * 20;
        box.position.y = Math.floor(Math.random() * 20) * 20 + 10;
        box.position.z = Math.floor(Math.random() * 20 - 10) * 20;

        group.add(box);
      }
      this.scene.add(group);
      this.objects.push(group);
    }
  }

  spawnObjectsInstancedMesh(): void {
    const matrix = new Matrix4();

    const position = this.objectGeometry.attributes.position;
    const colorsBox = [];

    for (let i = 0, l = position.count; i < l; i++) {
      this.color.setHSL(Math.random() * 0.3 + 0.5, 0.75, Math.random() * 0.25 + 0.75);
      colorsBox.push(this.color.r, this.color.g, this.color.b);
    }

    this.objectGeometry.setAttribute('color', new Float32BufferAttribute(colorsBox, 3));

    const boxMaterial = new MeshPhongMaterial({specular: 0xffffff, flatShading: true, vertexColors: true});
    boxMaterial.color.setHSL(0.60, 0.75, 0.81);
    boxMaterial.transparent = this.materialTransparency;
    boxMaterial.opacity = this.materialTransparency === true ? 0.2 : 1;

    if (this.useLod === true && this.objectGeometry.name === "sphere") {
      let lodMeshes: InstancedMesh[] = [];
      for (let i = 0; i < this.sphereLodGeometry.length; i++) {
        lodMeshes[i] = new InstancedMesh(this.sphereLodGeometry[i][0] as SphereGeometry, boxMaterial, this.objectsAmount);
      }

      for (let j = 0; j < this.objectsAmount; j++) {
        const lod = new LOD();
        this.randomizeMatrix(matrix);

        for (let i = 0; i < this.sphereLodGeometry.length; i++) {
          lodMeshes[i].setMatrixAt(j, matrix);
          lod.addLevel(lodMeshes[i], this.sphereLodGeometry[i][1] as number);
        }
        this.scene.add(lod);
        this.objects.push(lod);
      }
    } else {
      const mesh = new InstancedMesh(this.objectGeometry, boxMaterial, this.objectsAmount);
      mesh.castShadow = this.shadowsOn;
      mesh.receiveShadow = this.shadowsOn;

      for (let i = 0; i < this.objectsAmount; i++) {
        this.randomizeMatrix(matrix);
        mesh.setMatrixAt(i, matrix);
      }
      this.scene.add(mesh);
      this.objects.push(mesh);
    }
  }

  randomizeMatrix(matrix: Matrix4): void {
    const position = new Vector3();
    const rotation = new Euler();
    const quaternion = new Quaternion();
    const scale = new Vector3();

    position.x = Math.floor(Math.random() * 20 - 10) * 20;
    position.y = Math.floor(Math.random() * 20) * 20 + 10;
    position.z = Math.floor(Math.random() * 20 - 10) * 20;

    // rotation.x = Math.random() * 2 * Math.PI;
    // rotation.y = Math.random() * 2 * Math.PI;
    // rotation.z = Math.random() * 2 * Math.PI;

    quaternion.setFromEuler(rotation);

    scale.x = scale.y = scale.z = Math.random() * 1;

    matrix.compose(position, quaternion, scale);
  }

  ngOnInit() {
    this.createScene();
  }

  async createScene(): Promise<void> {
    await this.init();
    this.stats = Stats();
    this.stats.showPanel(0);
    this.container.appendChild(this.stats.dom);
    this.stats.dom.children[0].id = 'fpsCounter';

    this.animate();
  }

  onWindowResize(): void {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  }

  animate(): void {
    requestAnimationFrame(() => this.animate());

    this.drawCalls = this.renderer.info.render.calls;
    this.triangles = this.renderer.info.render.triangles;
    this.spinAround();
    this.fpsMeter();

    this.render();
    this.stats.begin();
    this.stats.end();
  }

  fpsMeter() {
    const canvas = $('#fpsCounter')[0] as HTMLElement;
    // @ts-ignore
    const value = canvas.getContext('2d');
    const fpsAmount = (canvas.getAttribute('fpsCounter'));
    if (this.canSpin) {
      this.measurements.fps.push(fpsAmount);
      this.measurements.drawCalls.push(this.drawCalls);
    }
  }

  spinAround() {
    if (this.canSpin) {
      this.theta += 0.5;
      this.camera.position.x = this.radius * Math.sin(MathUtils.degToRad(this.theta));
      this.camera.position.y = this.radius * Math.sin(MathUtils.degToRad(this.theta));
      this.camera.position.z = this.radius * Math.cos(MathUtils.degToRad(this.theta));
      this.camera.lookAt(this.scene.position);
      this.camera.updateMatrixWorld();

      if (parseInt(this.theta.toFixed(0)) > 350) {
        this.theta = 0;
        this.radius += 200;
      }
      if (this.radius === 500) {
        this.theta = 0;
        this.radius = 100;
        console.log(this.measurements);
        const jsonData = JSON.stringify(this.measurements);
        console.log(jsonData);
        this.measurements = null;
        this.canSpin = false;
      }
    }
  }

  render(): void {
    this.renderer.render(this.scene, this.camera);
  }

  createLight(): void {
    const light = new SpotLight(0xffffff, 1.5);
    light.position.set(0, 1500, 0);
    light.angle = Math.PI * 0.2;
    light.castShadow = this.shadowsOn;
    light.shadow.camera.near = 200;
    light.shadow.camera.far = 2000;
    light.shadow.bias = -0.000222;
    light.shadow.mapSize.width = 1024;
    light.shadow.mapSize.height = 1024;
    this.scene.add(light);
  }

  async init(): Promise<void> {
    this.container = document.getElementById('container');
    this.scene = new Scene();
    this.scene.background = new Color(0xf0f0f0);
    this.camera = new PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.01, 10000);
    this.camera.position.set(0, 250, 1000);
    this.scene.add(this.camera);

    // Lighting
    this.scene.add(new AmbientLight(0xf0f0f0));
    this.createLight();

    // Grid
    const helper = new GridHelper(20000, 1000);
    helper.position.y = -199;
    (helper.material as Material).opacity = 0.25;
    (helper.material as Material).transparent = true;
    helper.receiveShadow = this.shadowsOn;
    this.scene.add(helper);


    this.renderer = new WebGLRenderer({antialias: this.antiAliasing});
    this.renderer.setPixelRatio(window.devicePixelRatio);
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.shadowMap.type = PCFShadowMap; // default
    this.renderer.shadowMap.enabled = this.shadowsOn;

    this.container.appendChild(this.renderer.domElement);
    window.addEventListener('resize', () => this.onWindowResize());
    this.createControls();

    this.spawnObjects();
  }

  createControls(): void {
    // Orbit
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.dampingFactor = 0.2;
    this.controls.addEventListener('change', () => this.render());

    // Transform
    this.transformControl = new TransformControls(this.camera, this.renderer.domElement);
    this.transformControl.addEventListener('change', () => {
      this.render();
    });
    this.transformControl.addEventListener('dragging-changed', (event) => {
      this.controls.enabled = !event.value;
    });
    this.scene.add(this.transformControl);
  }
}
