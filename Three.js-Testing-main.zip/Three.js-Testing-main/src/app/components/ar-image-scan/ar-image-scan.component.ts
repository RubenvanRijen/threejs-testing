import { Component, OnInit, CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';


@Component({
  selector: 'app-ar-image-scan',
  templateUrl: './ar-image-scan.component.html',
  styleUrls: ['./ar-image-scan.component.scss']
})
export class ArImageComponent implements OnInit {




  constructor() { }

  ngOnInit(): void {
  }



}
