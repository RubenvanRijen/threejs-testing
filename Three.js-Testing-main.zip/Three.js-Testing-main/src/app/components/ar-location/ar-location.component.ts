import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ar-location',
  templateUrl: './ar-location.component.html',
  styleUrls: ['./ar-location.component.scss']
})
export class ArLocationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
