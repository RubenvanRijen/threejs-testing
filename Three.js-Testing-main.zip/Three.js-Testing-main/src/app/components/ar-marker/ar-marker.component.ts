import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ar-location',
  templateUrl: './ar-marker.component.html',
  styleUrls: ['./ar-marker.component.scss']
})
export class ArMarkerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
